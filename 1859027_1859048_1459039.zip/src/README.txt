﻿Lưu ý:
Bởi vì server sử dụng CSDL SQL nên phải cài file database.sql trên phpMyAdmin và bật chạy MySQL trên XAMMP(WAMP, MAMP,...) trước khi bật server